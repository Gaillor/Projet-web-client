// Récupérer les éléments HTML
const messages = document.getElementById('messages');
const messageInput = document.getElementById('message');
const sendBtn = document.getElementById('sendBtn');

// Fonction pour ajouter un message à la chatbox
function addMessage(message) {
  const messageEl = document.createElement('p');
  messageEl.innerText = `${message.date} ${message.time} ${message.user}: ${message.msg}`;
  messages.appendChild(messageEl);
}

// Fonction pour récupérer les messages via AJAX
function getMessages() {
  const xhr = new XMLHttpRequest();
  xhr.open('GET', '../htbin/chatget.py');
  xhr.onreadystatechange = function() {
    if (xhr.readyState === 4 && xhr.status === 200) {
      const messagesArray = JSON.parse(xhr.responseText);
      messages.innerHTML = '';
      messagesArray.forEach(function(message) {
        addMessage(message);
      });
    }
  };
  xhr.send();
}

// Fonction pour envoyer un message via AJAX
function sendMessage() {
  const message = messageInput.value;
  const xhr = new XMLHttpRequest();
  xhr.open('POST', '../htbin/chatsend.py');
  xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
  xhr.onreadystatechange = function() {
    if (xhr.readyState === 4 && xhr.status === 200) {
      const response = JSON.parse(xhr.responseText);
      if (response.num === 0) {
        addMessage(response.msg);
      } else {
        alert(`Erreur: ${response.msg}`);
      }
    }
  };
  xhr.send(`msg=${encodeURIComponent(message)}`);
  messageInput.value = '';
}

// Récupérer les messages existants lors du chargement de la page
getMessages();

// Ajouter un événement de clic sur le bouton d'envoi
sendBtn.addEventListener('click', function(event) {
  event.preventDefault();
  sendMessage();
});
