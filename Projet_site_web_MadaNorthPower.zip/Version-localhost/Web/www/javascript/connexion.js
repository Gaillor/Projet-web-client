document.getElementById("login-form").addEventListener("submit", function(event) {
    event.preventDefault();
    var username = document.getElementById("username").value;
    var userpwd = document.getElementById("userpwd").value;
    var errorMessage = document.getElementById("error-message");

    var xhr = new XMLHttpRequest();
    xhr.open("POST", "htbin/login.py", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4 && xhr.status === 200) {
            var response = xhr.responseText;
            errorMessage.innerHTML = response;
        }
    };

    var encodedData = "username=" + encodeURIComponent(username) + "&userpwd=" + encodeURIComponent(userpwd);
    xhr.send(encodedData);
});